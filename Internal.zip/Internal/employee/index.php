<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Emp Job Form</title>
</head>
<body>
    <h1>Emp Job Form</h1>
    <table>
        <form action="save_data.php" method="post" enctype="multipart/form-data">
            <tr>
                <td>Profile:</td>
                <td><input type="file" name="profile" accept=".jpg,.jpeg"></td>
            </tr>
            <tr>
                <td>Name:</td>
                <td><input type="text" name="name" required></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><input type="email" name="email" required></td>
            </tr>
            <tr>
                <td>Phone:</td>
                <td><input type="tel" name="phone" pattern="[0-9]{10}" required></td>
            </tr>
            <tr>
                <td>State:</td>
                <td><input type="text" name="state" required></td>
            </tr>
            <tr>
                <td>Zip:</td>
                <td><input type="number" name="zip"></td>
            </tr>
            <tr>
                <td>Position:</td>
                <td><input type="text" name="possition" required></td>
            </tr>
            <tr>
                <td>Resume:</td>
                <td><input type="file" name="resume" accept=".pdf" required></td>
            </tr>
            
            <tr>
                <td><input type="submit" name="submit" value="Submit"></td>
            </tr>
        </form>
    </table>
</body>
</html>
